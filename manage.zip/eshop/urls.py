from django.contrib import admin
from django.urls import path,include
from django.conf.urls.static import static
from . import settings
from . import views
from .views import home
from .views import signup
from .views import login
from .views import logout
from .views import cart

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home.Index.as_view(),name="homepage"),
    path('signup',views.signup.Signup.as_view()),
    path('login',views.login.Login.as_view(),name="login"),
    path('logout',views.logout.Logout,name="logout"),
    path('cart',views.cart.Cart.as_view(),name='cart'),
    path('checkupform',views.cart.Checkupform.as_view()),
    path('checkout',views.cart.CheckOut.as_view()),
] + static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
