from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password,check_password
from django.views import View
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer


class Signup(View):

    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        first_name = request.POST.get('firstname')
        last_name = request.POST.get('lastname')
        email = request.POST.get('email')
        mobile_number = request.POST.get('mnumber')
        password = request.POST.get('password')

        value = {
            'first_name': first_name,
            'last_name': last_name,
            'email': email,
            'mobile_number': mobile_number,
        }

        customer = Customer(first_name=first_name, last_name=last_name,
                            email=email, mobile_number=mobile_number, password=password)

        # Required
        error_name = None

        if (not first_name):
            error_name = "First Name is required !!"
        elif(len(first_name) < 4):
            error_name = "First Name required minimum 4 character !!"

        elif (not last_name):
            error_name = "Last Name is required !!"
        elif(len(last_name) < 4):
            error_name = "Last Name required minimum 4 character !!"

        elif (not mobile_number):
            error_name = "Mobile Number is required !!"
        elif(len(mobile_number) < 10):
            error_name = "Mobile Number required minimum 10 character !!"

        elif (not password):
            error_name = "First Name is required !!"
        elif(len(password) < 6):
            error_name = " Password required minimum 6 character !!"

        elif(Customer.isExist(email)):
            error_name = "Same email is already exists !!"

        # Saving
        if (not error_name):
            
            customer.password=make_password(customer.password)
            customer.register()
            return redirect('homepage')
        else:
            data = {
                'error': error_name,
                'value': value
            }
            return render(request, 'signup.html', data)
       