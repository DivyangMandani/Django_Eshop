from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password,check_password
from django.views import View
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer


class Login(View):

    def get(self, request):
        return render(request,'login.html')

    def post(self, request):
        email=request.POST.get('email')
        password=request.POST.get('password')

        customer = Customer.objects.get(email=email)
        error_name=None
        if customer:
            flag=check_password(password,customer.password)
            if flag:
                request.session['customer']=customer.id
                return redirect('homepage')
            else:
                error_name="Please enter correct password !!"    
        else:
            error_name="No email found !!"  
        return render(request, 'login.html',{'error':error_name}) 

        