from django.shortcuts import render, redirect
from django.views import View
from store.middlewares.auth_middleware import Auth_Middleware
from store.models.product import Product
from store.models.orders import Order
from store.models.customer import Customer
from django.utils.decorators import method_decorator


class Cart(View):

    def get(self,request):
        lst=list(request.session.get('cart'))
        cart_list=Product.objects.filter(id__in = lst)
        print(cart_list)

        return render(request, 'cart.html',{'cart_list':cart_list})

class Checkupform(View):
    @method_decorator(Auth_Middleware)
    def get(self,request):
        return render(request,'checkupform.html')   

class CheckOut(View) :

    
    def post(self,request):
        address=request.POST.get('address')
        mobile_number=request.POST.get('mobilenumber')
        customer=request.session.get('customer')
        cart=request.session.get('cart')
        cart_product=list(cart.keys())
        products=Product.objects.filter(id__in=cart_product)       

        for p in products:
            print()
            order=Order(product=p,customer=Customer(id=customer),price=p.price,address=address,mobile_number=mobile_number)
            order.get_order()

        request.session['cart']={}    

        return redirect('cart')           

