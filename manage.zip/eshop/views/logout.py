from django.shortcuts import redirect

def Logout(request):
    request.session.clear()
    return redirect('login')