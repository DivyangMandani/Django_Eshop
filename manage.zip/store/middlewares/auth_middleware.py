from django.shortcuts import redirect

def Auth_Middleware(get_response):

    def middleware(request):
        customer=request.session.get('customer')
        if not customer:
            return redirect('login')
        else:
            pass    

        response=get_response(request)
        return response

    return middleware